# Parlok Cafe — Online Ordering + Admin Panel

A full-stack starter project for Parlok Cafe with a premium dark/red cafe website, menu management, cart, customer ordering, WhatsApp order handoff, reviews, order management, admin-user management and website settings.

## Included

- Premium responsive customer website
- Parlok Cafe logo + menu card assets supplied for this project
- Menu categories, search-ready structure, quantities and cart
- Automatic total calculation
- Customer name, phone, address and order notes
- Order record saved on the server
- WhatsApp order message generated with order number, customer details, items, quantities and total
- Feedback submission + admin approval/delete moderation
- Admin dashboard with order/sales summary
- Menu add/edit/delete, price changes, availability toggle, Special and Best Seller flags
- Menu photo upload from the admin panel
- Order status: New, Confirmed, Preparing, Completed, Cancelled
- Admin add/delete with protection against deleting the last admin
- Website settings editable from the admin panel
- Google Maps, Facebook, Instagram, TikTok and WhatsApp buttons
- Mobile responsive UI
- Password hashing using Node's built-in `crypto.scryptSync`

## Important WhatsApp behavior

A normal public website cannot silently send a WhatsApp message to a cafe number without the WhatsApp Business/Cloud API and Meta credentials. This project creates the complete order on the server and then opens WhatsApp with a pre-filled message addressed to the cafe number. The customer taps Send in WhatsApp.

If you later want true server-to-WhatsApp automatic sending, connect Meta WhatsApp Cloud API and add its credentials/server integration. Do not put Meta secrets in frontend code.

## Run locally

1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Run:

```bash
npm install
npm start
```

4. Open `http://localhost:3000`
5. Admin panel: `http://localhost:3000/admin`

## Initial admin

Email: `mandallalbabu9988@gmail.com`

Password: `Welcome`

**Change this password immediately for a real public deployment.** The project hashes stored passwords; the initial password is only the initial credential requested for this build.

## Data storage

For this first version, data is stored in `data/db.json`. This makes the project simple to deploy and easy to back up. For a high-traffic production cafe, migrate the data layer to PostgreSQL/MySQL or another managed database.

Uploaded menu photos are stored in `private/uploads/`.

## Deployment notes

For production:

- Set a strong `SESSION_SECRET` environment variable.
- Use HTTPS.
- Use a managed/persistent disk for `data/` and `private/uploads/` if your host has ephemeral storage.
- Change the initial admin password.
- Add rate limiting and a reverse proxy/WAF for a public production deployment.
- If using WhatsApp Cloud API, keep API tokens server-side only.

## Cafe links configured

- Google Maps: the link supplied for Parlok Cafe
- Facebook: the link supplied for Parlok Cafe
- Instagram: `@parlok_cafe`
- TikTok: `@parlokcafe_58`
- WhatsApp: `9824814365` (configured with Nepal country code `977` for WhatsApp)

## Notes about menu data

The starter menu is entered from the menu card supplied in the conversation. The item images initially use the supplied menu-card image as a placeholder. Replace individual item images from **Admin → Menu → Edit** when you have separate food photos.

Prices are treated as the currency shown on the supplied menu card (`Rs.`).
