const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const UPLOAD_DIR = path.join(ROOT, 'private', 'uploads');
const SESSION_SECRET = process.env.SESSION_SECRET || 'parlok-cafe-change-me';
const sessions = new Map();

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const initialMenu = [
  ['Food','Chowmein (Veg)',110,'Veg chowmein','/assets/menu-card.jpeg'],
  ['Food','Chowmein (Egg)',130,'Egg chowmein','/assets/menu-card.jpeg'],
  ['Food','Chowmein (Chicken)',150,'Chicken chowmein','/assets/menu-card.jpeg'],
  ['Food','Lachha Paratha + Channa',135,'Lachha paratha served with channa','/assets/menu-card.jpeg'],
  ['Food','Fried Rice (Veg)',110,'Vegetable fried rice','/assets/menu-card.jpeg'],
  ['Food','Fried Rice (Egg)',130,'Egg fried rice','/assets/menu-card.jpeg'],
  ['Food','Fried Rice (Chicken)',150,'Chicken fried rice','/assets/menu-card.jpeg'],
  ['Food','French Fries',110,'Crispy french fries','/assets/menu-card.jpeg'],
  ['Food','Aalo Chop',70,'8 pcs per plate','/assets/menu-card.jpeg'],
  ['Food','Piyaj Pakoda',70,'Crispy onion pakoda','/assets/menu-card.jpeg'],
  ['Food','Aalo Sadeko',70,'Spicy potato sadeko','/assets/menu-card.jpeg'],
  ['Food','Chau Chau Sadeko',60,'Spicy noodles sadeko','/assets/menu-card.jpeg'],
  ['Food','Chatpate',50,'Classic spicy chatpate','/assets/menu-card.jpeg'],
  ['Food','Omelette',50,'Fresh omelette','/assets/menu-card.jpeg'],
  ['Food','Boiled Egg',40,'Boiled eggs','/assets/menu-card.jpeg'],
  ['Cold Drinks','Red Bull',150,'Energy drink','/assets/menu-card.jpeg'],
  ['Cold Drinks','Xtreme',160,'Cold energy drink','/assets/menu-card.jpeg'],
  ['Cold Drinks','Sprite',80,'Chilled soft drink','/assets/menu-card.jpeg'],
  ['Cold Drinks','Coca Cola',80,'Chilled soft drink','/assets/menu-card.jpeg'],
  ['Cold Drinks','Fanta',80,'Chilled soft drink','/assets/menu-card.jpeg'],
  ['Hot Drinks','Milk Tea',35,'Classic milk tea','/assets/menu-card.jpeg'],
  ['Hot Drinks','Masala Tea',40,'Masala tea','/assets/menu-card.jpeg'],
  ['Hot Drinks','Lemon Tea',35,'Fresh lemon tea','/assets/menu-card.jpeg'],
  ['Hot Drinks','Black Tea',35,'Black tea','/assets/menu-card.jpeg'],
  ['Hot Drinks','Hot Lemon',80,'Hot lemon','/assets/menu-card.jpeg'],
  ['Hot Drinks','Hot Lemon + Honey',90,'Hot lemon with honey','/assets/menu-card.jpeg'],
  ['Hot Drinks','Hot Lemon + Honey Ginger',100,'Hot lemon with honey and ginger','/assets/menu-card.jpeg'],
  ['Drinks','Gorkha Strong Beer (330 ml)',230,'330 ml','/assets/menu-card.jpeg'],
  ['Hookah','Hookah',299,'Hookah','/assets/menu-card.jpeg'],
  ['Hookah','Add-Coil',35,'Hookah add-on coil','/assets/menu-card.jpeg'],
  ['Smokes','Shikhar Ice',25,'Smoke item','/assets/menu-card.jpeg'],
  ['Smokes','Surya Red',30,'Smoke item','/assets/menu-card.jpeg'],
  ['Smokes','Surya Light',30,'Smoke item','/assets/menu-card.jpeg'],
  ['Smokes','Surya Arctic',35,'Smoke item','/assets/menu-card.jpeg'],
  ['Smokes','Surya Fusion',35,'Smoke item','/assets/menu-card.jpeg'],
  ['Smokes','B Premium',35,'Smoke item','/assets/menu-card.jpeg']
].map((x,i)=>({id:crypto.randomUUID(),category:x[0],name:x[1],price:x[2],description:x[3],image:x[4],available:true,special:false,bestSeller:false,sort:i+1}));

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}
function verifyPassword(password, stored) {
  const [salt, key] = String(stored).split(':');
  if (!salt || !key) return false;
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(key,'hex'), Buffer.from(derived,'hex'));
}
function loadDB() {
  if (!fs.existsSync(DB_FILE)) {
    const db={admins:[{id:crypto.randomUUID(),name:'Main Admin',email:'mandallalbabu9988@gmail.com',passwordHash:hashPassword('Welcome'),createdAt:new Date().toISOString()}],menu:initialMenu,feedback:[],orders:[],settings:{}};
    saveDB(db); return db;
  }
  const db=JSON.parse(fs.readFileSync(DB_FILE,'utf8'));
  if (!db.admins?.length) db.admins=[{id:crypto.randomUUID(),name:'Main Admin',email:'mandallalbabu9988@gmail.com',passwordHash:hashPassword('Welcome'),createdAt:new Date().toISOString()}];
  if (!db.menu?.length) db.menu=initialMenu;
  db.feedback ||= []; db.orders ||= []; db.settings={...defaultSettings,...(db.settings||{})};
  saveDB(db); return db;
}
const defaultSettings={cafeName:'Parlok Cafe',tagline:'Good Food • Good Tea • Good Vibes',phone:'9824814365',whatsapp:'9779824814365',currency:'Rs.',openingHours:'10:00 AM – 10:00 PM',address:'Parlok Cafe, Nepal',mapUrl:'https://maps.app.goo.gl/bJNaDEikP9yoa2eb9?g_st=ic',facebook:'https://www.facebook.com/share/1J5ZWU7MUR/?mibextid=wwXIfr',instagram:'https://www.instagram.com/parlok_cafe?stkn=MXN0ZzFia2dleGJmbQ==',tiktok:'https://www.tiktok.com/@parlokcafe_58?is_from_webapp=1&sender_device=pc',heroText:'Deliciously Heavenly Food',offerActive:false,offerText:"Weekend Special — ask us about today's offer!",discountPercent:0};
function saveDB(db){fs.writeFileSync(DB_FILE,JSON.stringify(db,null,2));}
let db=loadDB(); db.settings={...defaultSettings,...db.settings}; saveDB(db);

const upload = multer({storage:multer.diskStorage({destination:UPLOAD_DIR,filename:(req,file,cb)=>{const ext=path.extname(file.originalname).toLowerCase(); cb(null,`${Date.now()}-${crypto.randomBytes(5).toString('hex')}${ext}`);}}),limits:{fileSize:4*1024*1024},fileFilter:(req,file,cb)=>cb(null,/^image\/(jpeg|png|webp|gif)$/.test(file.mimetype))});
app.use(express.json({limit:'1mb'}));
app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(ROOT,'public')));

function clean(s,max=300){return String(s??'').trim().slice(0,max)}
function auth(req,res,next){
  const token=req.get('x-admin-token') || req.cookies?.parlok; const session=sessions.get(token);
  if(!session) return res.status(401).json({error:'UNAUTHORIZED',message:'Timi admin xainau / You are not an admin.'});
  req.admin=session; next();
}
// Simple cookie parser
app.use((req,res,next)=>{req.cookies={};const raw=req.headers.cookie||'';raw.split(';').forEach(p=>{const [k,...v]=p.trim().split('=');if(k) req.cookies[k]=decodeURIComponent(v.join('='));});next();});

app.get('/api/public',(req,res)=>res.json({settings:db.settings,menu:db.menu.filter(x=>x.available),feedback:db.feedback.filter(x=>x.approved).sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)).slice(0,20)}));
app.post('/api/orders',(req,res)=>{
  const {name,phone,address,notes,items}=req.body;
  if(!clean(name,100)||!clean(phone,30)||!clean(address,300)||!Array.isArray(items)||!items.length) return res.status(400).json({error:'Please fill name, phone, address and select at least one item.'});
  const orderItems=[]; let total=0;
  for(const line of items){const item=db.menu.find(x=>x.id===line.id && x.available);const qty=Math.max(1,Math.min(99,Number(line.qty)||1));if(item){const amount=item.price*qty;orderItems.push({id:item.id,name:item.name,price:item.price,qty,amount});total+=amount;}}
  if(!orderItems.length)return res.status(400).json({error:'Selected items are unavailable. Please refresh the menu.'});
  const discountPercent=Math.max(0,Math.min(100,Number(db.settings.discountPercent)||0));
  const subtotal=total;
  const discount=db.settings.offerActive?Math.round(subtotal*discountPercent/100):0;
  total=subtotal-discount;
  const order={id:crypto.randomUUID(),orderNo:`P${Date.now().toString().slice(-7)}`,name:clean(name,100),phone:clean(phone,30),address:clean(address,300),notes:clean(notes,500),items:orderItems,subtotal,discount,total,status:'new',createdAt:new Date().toISOString()};
  db.orders.push(order); saveDB(db);
  const lines=[`🔔 NEW ORDER — ${db.settings.cafeName}`,``,`👤 Customer: ${order.name}`,`📞 Phone: ${order.phone}`,`📍 Address: ${order.address}`,order.notes?`📝 Notes: ${order.notes}`:'',``,`🧾 Order: ${order.orderNo}`,...order.items.map(i=>`• ${i.name} × ${i.qty} = ${db.settings.currency}${i.amount}`),``,`💵 SUBTOTAL: ${db.settings.currency}${order.subtotal}`,order.discount?`🏷️ DISCOUNT: -${db.settings.currency}${order.discount}`:'',`💰 TOTAL: ${db.settings.currency}${order.total}`,``,`Please confirm this order.`].filter(Boolean);
  const wa=`https://wa.me/${db.settings.whatsapp.replace(/\D/g,'')}?text=${encodeURIComponent(lines.join('\n'))}`;
  res.json({ok:true,order,whatsappUrl:wa});
});
app.post('/api/feedback',(req,res)=>{const {name,rating,message}=req.body;const r=Math.max(1,Math.min(5,Number(rating)||5));if(!clean(name,80)||!clean(message,600))return res.status(400).json({error:'Please enter your name and feedback.'});const fb={id:crypto.randomUUID(),name:clean(name,80),rating:r,message:clean(message,600),approved:false,createdAt:new Date().toISOString()};db.feedback.push(fb);saveDB(db);res.json({ok:true,message:'Thanks! Your feedback was submitted and is waiting for approval.'});});

app.post('/api/admin/login',(req,res)=>{const email=clean(req.body.email,160).toLowerCase();const password=String(req.body.password||'');const admin=db.admins.find(a=>a.email.toLowerCase()===email);if(!admin||!verifyPassword(password,admin.passwordHash))return res.status(401).json({error:'ADMIN_ONLY',message:'Timi admin xainau / You are not an admin.'});const token=crypto.randomBytes(32).toString('hex');sessions.set(token,{id:admin.id,email:admin.email,name:admin.name});res.cookie='';res.setHeader('Set-Cookie',`parlok=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=86400`);res.json({ok:true,admin:{id:admin.id,name:admin.name,email:admin.email},token});});
app.post('/api/admin/logout',auth,(req,res)=>{const token=req.get('x-admin-token')||req.cookies.parlok;sessions.delete(token);res.setHeader('Set-Cookie','parlok=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');res.json({ok:true});});
app.get('/api/admin/me',auth,(req,res)=>res.json({admin:req.admin}));
app.get('/api/admin/dashboard',auth,(req,res)=>{const today=new Date().toISOString().slice(0,10);const todayOrders=db.orders.filter(o=>o.createdAt.slice(0,10)===today);res.json({orders:db.orders.slice().sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)),feedback:db.feedback.slice().sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)),admins:db.admins.map(a=>({id:a.id,name:a.name,email:a.email,createdAt:a.createdAt})),menu:db.menu,stats:{todayOrders:todayOrders.length,todaySales:todayOrders.reduce((s,o)=>s+o.total,0),pending:db.orders.filter(o=>['new','confirmed','preparing'].includes(o.status)).length,totalOrders:db.orders.length,totalSales:db.orders.reduce((s,o)=>s+o.total,0)}})});
app.post('/api/admin/menu',auth,upload.single('image'),(req,res)=>{const {id,name,category,price,description,available,special,bestSeller}=req.body;if(!clean(name,120)||!clean(category,60)||!Number.isFinite(Number(price)))return res.status(400).json({error:'Name, category and valid price are required.'});let item=id?db.menu.find(x=>x.id===id):null;if(id&&!item)return res.status(404).json({error:'Item not found'});if(!item){item={id:crypto.randomUUID(),sort:db.menu.length+1};db.menu.push(item);}item.name=clean(name,120);item.category=clean(category,60);item.price=Math.max(0,Number(price));item.description=clean(description,250);item.available=available!=='false';item.special=special==='true';item.bestSeller=bestSeller==='true';if(req.file)item.image=`/private-upload/${req.file.filename}`;else if(!item.image)item.image='/assets/menu-card.jpeg';saveDB(db);res.json({ok:true,item});});
app.delete('/api/admin/menu/:id',auth,(req,res)=>{const i=db.menu.findIndex(x=>x.id===req.params.id);if(i<0)return res.status(404).json({error:'Item not found'});db.menu.splice(i,1);saveDB(db);res.json({ok:true});});
app.patch('/api/admin/menu/:id/toggle',auth,(req,res)=>{const item=db.menu.find(x=>x.id===req.params.id);if(!item)return res.status(404).json({error:'Item not found'});item.available=Boolean(req.body.available);saveDB(db);res.json({ok:true,item});});
app.patch('/api/admin/orders/:id',auth,(req,res)=>{const o=db.orders.find(x=>x.id===req.params.id);if(!o)return res.status(404).json({error:'Order not found'});const allowed=['new','confirmed','preparing','completed','cancelled'];if(!allowed.includes(req.body.status))return res.status(400).json({error:'Invalid status'});o.status=req.body.status;saveDB(db);res.json({ok:true,order:o});});
app.patch('/api/admin/feedback/:id',auth,(req,res)=>{const f=db.feedback.find(x=>x.id===req.params.id);if(!f)return res.status(404).json({error:'Feedback not found'});f.approved=Boolean(req.body.approved);saveDB(db);res.json({ok:true,feedback:f});});
app.delete('/api/admin/feedback/:id',auth,(req,res)=>{const i=db.feedback.findIndex(x=>x.id===req.params.id);if(i<0)return res.status(404).json({error:'Feedback not found'});db.feedback.splice(i,1);saveDB(db);res.json({ok:true});});
app.post('/api/admin/admins',auth,(req,res)=>{const name=clean(req.body.name,80),email=clean(req.body.email,160).toLowerCase(),password=String(req.body.password||'');if(!name||!email||password.length<8)return res.status(400).json({error:'Name, valid email and password of at least 8 characters are required.'});if(db.admins.some(a=>a.email.toLowerCase()===email))return res.status(409).json({error:'Admin already exists'});const a={id:crypto.randomUUID(),name,email,passwordHash:hashPassword(password),createdAt:new Date().toISOString()};db.admins.push(a);saveDB(db);res.json({ok:true,admin:{id:a.id,name:a.name,email:a.email,createdAt:a.createdAt}});});
app.delete('/api/admin/admins/:id',auth,(req,res)=>{if(db.admins.length<=1)return res.status(400).json({error:'The last remaining admin cannot be deleted.'});if(req.params.id===req.admin.id)return res.status(400).json({error:'For safety, you cannot delete the admin account currently logged in.'});const i=db.admins.findIndex(a=>a.id===req.params.id);if(i<0)return res.status(404).json({error:'Admin not found'});db.admins.splice(i,1);saveDB(db);res.json({ok:true});});
app.patch('/api/admin/settings',auth,(req,res)=>{for(const k of Object.keys(defaultSettings))if(k in req.body){if(k==='offerActive')db.settings[k]=Boolean(req.body[k]);else if(k==='discountPercent')db.settings[k]=Math.max(0,Math.min(100,Number(req.body[k])||0));else db.settings[k]=clean(req.body[k],500)}saveDB(db);res.json({ok:true,settings:db.settings});});

// Serve uploaded item images only through this route after they are known to exist.
app.get('/private-upload/:file',(req,res)=>{const safe=path.basename(req.params.file);const p=path.join(UPLOAD_DIR,safe);if(!fs.existsSync(p))return res.status(404).end();res.sendFile(p);});
app.get('/admin',(req,res)=>res.sendFile(path.join(ROOT,'public','admin.html')));
app.get('*',(req,res)=>res.sendFile(path.join(ROOT,'public','index.html')));
app.listen(PORT,()=>console.log(`Parlok Cafe running at http://localhost:${PORT}`));
